package com.r.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin("*")
@RestController
@RequestMapping("/email")
public class EmailController {

    @PostMapping("/send")
    public String sendEmail(@RequestParam String vendorName, @RequestParam String upi) {
        // Mock email sending
        String emailContent = "Sending payments to vendor " + vendorName + " at upi " + upi;
        System.out.println(emailContent);
        return emailContent;
    }
}