package com.r.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Employee")
public class Employee {

    private int ctc;
    private String designation;
    
    @Id
    private String email;
    private String name;
	public int getCtc() {
		return ctc;
	}
	public void setCtc(int ctc) {
		this.ctc = ctc;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Employee(int ctc, String designation, String email, String name) {
		super();
		this.ctc = ctc;
		this.designation = designation;
		this.email = email;
		this.name = name;
	}

	
	public Employee() {
		
	}
	@Override
	public String toString() {
		return "Employee [ctc=" + ctc + ", designation=" + designation + ", email=" + email + ", name=" + name + "]";
	}
	
	
    // Getters and setters
}






