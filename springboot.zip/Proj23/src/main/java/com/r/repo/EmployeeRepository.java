package com.r.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.r.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, String> {
	
}


