package com.r.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.r.entity.Vendor;

public interface VendorRepository extends JpaRepository<Vendor, String> {
	
}