package com.r;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proj23Application {

	public static void main(String[] args) {
		SpringApplication.run(Proj23Application.class, args);
	}

}
