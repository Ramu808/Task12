
import axios from 'axios';

const API_URL = 'http://localhost:8080';

export const createEmployee = (employee) => axios.post(`${API_URL}/employees`, employee);
export const getEmployees = () => axios.get(`${API_URL}/employees`);

export const createVendor = (vendor) => axios.post(`${API_URL}/vendors`, vendor);
export const getVendors = () => axios.get(`${API_URL}/vendors`);

export const sendEmail = (vendorName, upi) => axios.post(`${API_URL}/email/send`, null, {
    params: { vendorName, upi }
});
