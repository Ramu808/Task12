// pages/index.js
import { useState, useEffect } from 'react';
import { createEmployee, getEmployees, createVendor, getVendors, sendEmail } from '.Services/Services/api';

const Home = () => {
    const [employees, setEmployees] = useState([]);
    const [vendors, setVendors] = useState([]);
    const [employeeForm, setEmployeeForm] = useState({ name: '', designation: '', ctc: '', email: '' });
    const [vendorForm, setVendorForm] = useState({ name: '', email: '', upi: '' });

    useEffect(() => {
        fetchEmployees();
        fetchVendors();
    }, []);

    const fetchEmployees = async () => {
        const { data } = await getEmployees();
        setEmployees(data);
    };

    const fetchVendors = async () => {
        const { data } = await getVendors();
        setVendors(data);
    };

    const handleEmployeeSubmit = async (e) => {
        e.preventDefault();
        await createEmployee(employeeForm);
        fetchEmployees();
    };

    const handleVendorSubmit = async (e) => {
        e.preventDefault();
        await createVendor(vendorForm);
        fetchVendors();
    };

    const handleSendEmail = async (vendor) => {
        await sendEmail(vendor.name, vendor.upi);
        alert(`Email sent to ${vendor.name}`);
    };

    return (
        <div>
            <h1>Employees</h1>
            <form onSubmit={handleEmployeeSubmit}>
                <input
                    type="text"
                    placeholder="Name"
                    value={employeeForm.name}
                    onChange={(e) => setEmployeeForm({ ...employeeForm, name: e.target.value })}
                />
                <input
                    type="text"
                    placeholder="Designation"
                    value={employeeForm.designation}
                    onChange={(e) => setEmployeeForm({ ...employeeForm, designation: e.target.value })}
                />
                <input
                    type="number"
                    placeholder="CTC"
                    value={employeeForm.ctc}
                    onChange={(e) => setEmployeeForm({ ...employeeForm, ctc: e.target.value })}
                />
                <input
                    type="email"
                    placeholder="Email"
                    value={employeeForm.email}
                    onChange={(e) => setEmployeeForm({ ...employeeForm, email: e.target.value })}
                />
                <button type="submit">Add Employee</button>
            </form>
            <ul>
                {employees.map((employee) => (
                    <li key={employee.email}>{employee.name} - {employee.designation}</li>
                ))}
            </ul>

            <h1>Vendors</h1>
            <form onSubmit={handleVendorSubmit}>
                <input
                    type="text"
                    placeholder="Name"
                    value={vendorForm.name}
                    onChange={(e) => setVendorForm({ ...vendorForm, name: e.target.value })}
                />
                <input
                    type="email"
                    placeholder="Email"
                    value={vendorForm.email}
                    onChange={(e) => setVendorForm({ ...vendorForm, email: e.target.value })}
                />
                <input
                    type="text"
                    placeholder="UPI"
                    value={vendorForm.upi}
                    onChange={(e) => setVendorForm({ ...vendorForm, upi: e.target.value })}
                />
                <button type="submit">Add Vendor</button>
            </form>
            <ul>
                {vendors.map((vendor) => (
                    <li key={vendor.email}>
                        {vendor.name} - {vendor.upi}
                        <button onClick={() => handleSendEmail(vendor)}>Send Email</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Home;
